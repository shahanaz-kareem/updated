# Join Storybox

This is a simple exercise to help the hiring process. We would love people with prior
experience with Git.

You can be descriptive as much as you want. Committing individual steps will earn you extra points.


## How to apply?

 1. Fork this repository.
 2. Read questions in `questions.md`
 3. Write the answers in `answers.md`
 4. Submit a `Pull Request` once you're finish with all the questions.

*If you have any doubts please open an issue in this very repository*
