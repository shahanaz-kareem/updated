## About You.
1. my self shahanaz numudeen iam from trivandrum .
 i have completed my btech in 2017 in computer science.I worked at websoullabs in laravel as intern i have done 3 portifolios there 2 in laravel
 as full stack with backend  1 in angular only front end . then i was worked as deropstuf technologies kowdiar as php developer REST API they hired me for 3 months .currently iam working in black salt as laravel developer and currently i have commited to client project koora app. it was upto to the end in koora i have done frontend and integration and small parts in backend like login registration and all.

 My current ctc is 15,000 iam expecting 15000-200000

 I dont have further notice period i want 1 weak to complete my project which i was commited now .


 thank you shahanaz Nujumudeen



2. currently using windows10 ans visual studio code as IDE.


## Social Profile
1. https://github.com/shahanaz-kareem/shahanaz-kareem/new/main?filename=README.md&path=%2F&value=-+%F0%9F%91%8B+Hi%2C+I%E2%80%99m+%40shahanaz-kareem%0A-+%F0%9F%91%80+I%E2%80%99m+interested+in+...%0A-+%F0%9F%8C%B1+I%E2%80%99m+currently+learning+...%0A-+%F0%9F%92%9E%EF%B8%8F+I%E2%80%99m+looking+to+collaborate+on+...%0A-+%F0%9F%93%AB+How+to+reach+me+...%0A%0A%3C%21---%0Ashahanaz-kareem%2Fshahanaz-kareem+is+a+%E2%9C%A8+special+%E2%9C%A8+repository+because+its+%60README.md%60+%28this+file%29+appears+on+your+GitHub+profile.%0AYou+can+click+the+Preview+link+to+take+a+look+at+your+changes.%0A---%3E%0A =>git


https://www.linkedin.com/in/shahanaz-nujumudeen-720284168/=>linked in

# The real stuff.
1.
PHP,Mysql


2.
<?php
function numberConvertion($num = 1234)
{
    $result = str_split($num);
    return $result;
}
?>





3.  
<?php

$string = 'join with storybox';
$array = explode(" ",$string);
$piglatin = "";
foreach($array as $word)
{
    $word = trim($word);
    $first = substr($word,0,1);
    $thsh = substr($word,1,2);
    $thshrest = substr($word,2, strlen($word)-2);
    $rest = substr($word,1, strlen($word)-1);
    if(trim($word))
    {
        $piglatin = (strlen($word)==1)?$first." ":$rest.$first. "ay ";
    }

}
echo $piglatin;
?>





4.
<?php  

$number = array(1,2,3,4,5,6);
for($i=0;$i<=1;i++)
{
    array_push($number, array_shift($number));

}   
print_r($number);
?>  
 